using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddCors();
builder.Services.AddHttpClient();
builder.Services.AddDbContext<AppDb>(opt => opt.UseSqlite("Data Source=diploma_smarthome.db"));

var app = builder.Build();

// ТОКЕН, ЯКИЙ ТИ ОТРИМАВ (ВСТАВ ЙОГО СЮДИ)
string hueToken = "4fe94a78899b6c667874ec39a57ccb2";

app.UseDefaultFiles();
app.UseStaticFiles();
app.UseCors(x => x.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod());

// 1. Отримання даних
app.MapGet("/api/lights/sync", async (IHttpClientFactory clientFactory) =>
{
    var client = clientFactory.CreateClient();
    var response = await client.GetAsync($"http://localhost:8000/api/{hueToken}/lights");
    return Results.Content(await response.Content.ReadAsStringAsync(), "application/json");
});

// 2. Керування лампою
app.MapPost("/api/lights/{id}/state", async (string id, Microsoft.AspNetCore.Http.HttpRequest req, IHttpClientFactory clientFactory) =>
{
    using var reader = new StreamReader(req.Body);
    var rawJson = await reader.ReadToEndAsync();

    var client = clientFactory.CreateClient();
    var content = new StringContent(rawJson, System.Text.Encoding.UTF8, "application/json");

    // Стукаємося точно з токеном!
    var response = await client.PutAsync($"http://localhost:8000/api/{hueToken}/lights/{id}/state", content);
    return Results.Ok();
});

app.Run("http://localhost:5000");

public class AppDb : DbContext { public AppDb(DbContextOptions<AppDb> options) : base(options) { } public DbSet<LogEntry> Logs => Set<LogEntry>(); }
public class LogEntry { public int Id { get; set; } public string Action { get; set; } = ""; }